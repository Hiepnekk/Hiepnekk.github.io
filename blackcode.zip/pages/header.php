<nav class="navbar navbar-default navbar-top">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
<span class="sr-only">Menu</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a href="/"><img class="navbar-brand" src="/images/logo.png"  alt="Nạp thẻ Garena"></a>
<br><br>
</div>
</div>
</div>
</div>
</nav>