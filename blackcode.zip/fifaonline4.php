<!DOCTYPE html>
    <html lang="vi">
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="author" content="Nạp thẻ FIFA Online 4">

    <link rel="icon" type="image/png" href="images/favicon.ico">

    <title>FIFA Online 4 - Trung tâm nạp thẻ Garena</title>
    
    <meta name="description" content="Trang nạp FC FIFA Online 4 là đối tác chính thức của nhà phát hành Garena" />
    <meta name="keywords" content="nạp FIFA Online 4, nạp thẻ FIFA Online 4, nạp FC FIFA Online 4, nạp game FIFA Online 4, nạp tiền vào FIFA Online 4, nạp FC FIFA Online 4 miễn phí, nạp FIFA Online 4 vn, nạp FIFA Online 4 x5 FC, nạp FC FIFA Online 4 giá rẻ, shop nạp FC FIFA Online 4, nạp FC FIFA Online 4 x10, nạp FC FIFA Online 4 20k, nạp FC FIFA Online 4 10k, shop nạp FC FIFA Online 4 uy tín, nạp FC FIFA Online 4 giá rẻ 10k, nạp FC FIFA Online 4 giá rẻ, nạp FC FIFA Online 4 bằng thẻ viettel, nạp FC vào game FIFA Online 4, ... thì napgameauto.com chính là lựa chọn của bạn.">
    <meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/napthe1.css">
    <link href="css/style.css" rel="stylesheet">


    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom1.js"></script>

</head>
<?php
include "pages/header.php";
?>

<section>
<div class="container">

<?php
include "pages/banner.php";
?>

<div class="main-section__title"><div class="main-section__title-txt main-section__title-channel"><img src="https://cdngarenanow-a.akamaihd.net/gop/app/0000/032/837/icon.png" style="width:25px;height:25px;"> &nbsp; FIFA Online 4</div></div>

<div class="alert alert-info">Nhận ngay ×2 gói cầu thủ <b><font color="red">ICON 109+</font></b> khi nạp thẻ <b>lần đầu</b> có mệnh giá từ <span style="color:#ff0000;"><b>200.000</b>đ</span> trở lên.<br/><div style="padding:3px;"></div><span style="font-style: italic; font-size: 13px; margin-top:15px;color:#008000;">(Chú ý: Mỗi IP chỉ được hưởng ưu đãi một lần. Hệ thống nhận thấy địa chỉ IP của bạn chưa từng nạp thẻ)</span></div>

<div class="row">
<div class="col-md-6">
<div class="form-thanh-toan">

<form action="" method="POST"> 

<div>
<label for="mathe">Tên đăng nhập Garena:</label>
<input type="text" class="form-control" value="" name="account" placeholder="Nhập tên đăng nhập Garena">
</div>


<div>
<label>Loại thẻ:</label>
<br/>
<input type="hidden" name="loaithe" value="">
<img class="loai-the" src="images/viettel.png" title="Nạp thẻ Free Fire bằng thẻ Viettel" alt="VIETTEL" value="Viettel">          
<img class="loai-the" src="images/mobifone.png" title="Nạp thẻ Free Fire bằng thẻ Mobifone" alt="MOBIFONE" value="MobiFone">         
<img class="loai-the" src="images/vinaphone.png" title="Nạp thẻ Free Fire bằng thẻ Vinaphone" alt="VINAPHONE" value="VinaPhone">
<img class="loai-the" src="images/vietnamobile.png" title="Nạp thẻ Free Fire bằng thẻ Garena" alt="VNMOBI" value="Vietnamobile">
<img class="loai-the" src="images/gate.png" title="Nạp thẻ Free Fire bằng thẻ GATE" alt="GATE" value="Gate">
</div>

<div>
<label for="menhgia">Mệnh giá thẻ:</label> <span style="font-style: italic; font-size: 13px; margin-top:15px;color:red;">(Chú ý: nếu chọn sai mệnh giá sẽ bị mất thẻ)</span>
<select name="menhgia" id="menhgia" class="form-control" required="required">
<option value="0" selected="selected">- Chọn mệnh giá -</option>
<option value="50000">50.000đ</option>
<option value="100000">100.000đ</option>
<option value="200000">200.000đ</option>
<option value="500000">500.000đ</option>
<option value="1000000">1.000.000đ</option>
</select>				
</div>

<div>
<label for="mathe">Mã thẻ:</label>
<input type="text" class="form-control" name="mathe" id="mathe" placeholder="Nhập mã dưới lớp tráng bạc ...">
</div>

<div>
<label for="seri">Số seri:</label>
<input type="text" class="form-control" name="seri" id="seri" placeholder="Nhập số seri in trên thẻ ...">
</div>

<p style="font-style: italic;font-size: 13px; margin-top:15px;">* Bằng cách nhấn "NẠP THẺ" đồng nghĩa bạn đã chấp nhận điều khoản của trang web.</p>

<div class="error-msg thongbaoloi hide"></div>  <!--- Thông báo lỗi nhập thiếu -->

<?php
include "checking.php";
?>

<div style="padding-top: 8px;"><button type="submit" id="napthe" name="napthe" class="btn btn-danger btn-block" data-loading-text="<i class='fa fa-spinner fa-spin'></i> ĐANG NẠP THẺ">NẠP THẺ</button></div></form>

</div>
</div>

<div class="col-md-offset-1 col-md-5" >
<h2 class="table-title" style="padding-top: 10px;"><b>Bảng giá quy đổi FC</b></h2>
<div class="alert alert-info">Ưu đãi nhận thêm <b><font color="red">200%</font></b> giá trị thẻ cào khi nạp <strong>FC</strong> bằng thẻ <span style="color:#ff0000;"><b>Viettel Telecom</b></span>.</div>
<table class="table table-hover" style="-webkit-box-shadow: 0 0 20px 0 rgb(0 0 0 / 10%);box-shadow: 0 0 20px 0 rgb(0 0 0 / 10%);">
<thead>
<tr>
<th class="text-danger" style="border: 1px solid #e1e1e1; text-align: center;">Mệnh giá</th>
<th class="text-danger" style="border: 1px solid #e1e1e1;  text-align: center;">FC</th>
</tr>
</thead>
<tbody>
<tr>
<td style="border: 1px solid #e1e1e1; text-align: center;">10 000 VNĐ</td>
<td style="border: 1px solid #e1e1e1;  text-align: center;">Không hỗ trợ</td>
</tr>
<tr>
<td style="border: 1px solid #e1e1e1; text-align: center;">20 000 VNĐ</td>
<td style="border: 1px solid #e1e1e1;  text-align: center;">Không hỗ trợ</td>
</tr>
<tr>
<td style="border: 1px solid #e1e1e1; text-align: center;">50 000 VNĐ</td>
<td style="border: 1px solid #e1e1e1;  text-align: center;">FC × 210 <span style="color:#008000;">(+ 420)</span></td>
</tr>
<tr>
<td style="border: 1px solid #e1e1e1; text-align: center;">100 000 VNĐ</td>
<td style="border: 1px solid #e1e1e1;  text-align: center;">FC × 425 <span style="color:#008000;">(+ 850)</span></td>
</tr>
<tr>
<td style="border: 1px solid #e1e1e1; text-align: center;">200 000 VNĐ</td>
<td style="border: 1px solid #e1e1e1;  text-align: center;">FC × 1070 <span style="color:#008000;">(+ 2140)</span></td>
</tr>
<tr>
<td style="border: 1px solid #e1e1e1; text-align: center;">500 000 VNĐ</td>
<td style="border: 1px solid #e1e1e1;  text-align: center;">FC  × 2 200 <span style="color:#008000;">(+ 4 400)</span></td>
</tr>
<td style="border: 1px solid #e1e1e1; text-align: center;">1 000 000 VNĐ</td>
<td style="border: 1px solid #e1e1e1;  text-align: center;">FC  × 5 100 <span style="color:#008000;">(+ 10 200)</span></td>
</tr>
</tbody>
</table>
</div>
</div>
<hr/>

<h4>Giới thiệu</h4>
    <ul>
        <li>Được phát triển bởi đội ngũ quản trị viên thuộc nhà phát hành Garena. <strong><a style="color: #C9302C;" href="https://napgarena.vn">napgarena.vn</a></strong> luôn cho khách hàng sự tin tưởng và ưu đãi nhiều nhất khi <strong>nạp thẻ FIFA Online 4</strong> tại <strong><a style="color: #C9302C;" href="https://napgarena.vn">napgarena.vn</a></strong>.</li>
        <li>Là trang nạp thẻ được cấp phép bởi nhà phát hành nên các hành động nạp thẻ trên hệ thống của chúng tôi đảm bảo <strong>an toàn</strong> tuyệt đối cho tài khoản của khách hàng.</li>
        <li><strong>FC FIFA Online 4</strong> sẽ được chuyển ngay lập tức vào tài khoản sau khi nạp thẻ.</li>
        <li>Khách hàng có thể yên tâm sử dụng dịch vụ của chúng tôi mà không cần lo ngại về vấn đề bảo mật.</li>
    </ul>

<hr/>

<h4>Hướng dẫn nạp thẻ</h4>
<ol>
    <li>Khách hàng cần chuẩn bị thẻ cào hợp lệ được cung cấp trên hệ thống. Các thẻ cào hợp lệ như <strong>Viettel</strong>, <strong>Vinaphone</strong>, <strong>Mobifone</strong>, <strong>Vietnamobile</strong> và <strong>GATE</strong>.</li>
    <li>Khách hàng nhập đầy đủ thông tin vào bảng nạp thẻ bao gồm: Tên HLV <strong>FIFA Online 4</strong>, chọn loại thẻ cần nạp, chọn mệnh giá của thẻ cào, điền số seri và mã thẻ cần nạp.</li>
    <li>Sau khi điền đầy đủ thông tin, khách hàng cần kiểm tra lại kỹ thông tin của mình để tránh trường hợp nhập sai dẫn đến bị mất thẻ.</li>
    <li>Khi đã kiểm tra thông tin điền vào bảng là chính xác. Khách hàng bấm vào nút <strong>"NẠP THẺ"</strong>.</li>
    <li>Sau khi bấm nút <strong>"NẠP THẺ"</strong> quý khách hàng vui lòng đợi hệ thống kiểm tra. Hệ thống kiểm tra hoàn tất quý khách hàng vui lòng đăng nhập vào game để nhận FC và phần thưởng.</li>
</ol>

<?php
include "pages/footer.php";
?>

<script>
function getRecaptcha() {

}
</script>

</body>
</html>